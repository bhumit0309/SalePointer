<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    $t1 = $_POST[test1];
    $t2 = $_POST[test2];
    $r="t1=". $t1.","."t2=".$t2;
    echo $r;
 ?>
